package com.example.citycyclerentals;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddBikesActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_bikes);

        databaseHelper = new DatabaseHelper(this);

        EditText bikeIdSpace = findViewById(R.id.bikeidspace);
        EditText bikeColourSpace = findViewById(R.id.bikecolourspace);
        EditText bikeNumberSpace = findViewById(R.id.bikenumberspace);
        EditText priceSpace = findViewById(R.id.pricespace);
        EditText availabilitySpace = findViewById(R.id.availabilityspace);    //acc
        EditText availableLocationSpace = findViewById(R.id.availablelocationspace);
        Button addBikeButton = findViewById(R.id.adminaddbikesbutton);

        addBikeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String bikeId = bikeIdSpace.getText().toString().trim();
                String bikeColour = bikeColourSpace.getText().toString().trim();
                String bikeNumber = bikeNumberSpace.getText().toString().trim();
                String price = priceSpace.getText().toString().trim();
                String availability = availabilitySpace.getText().toString().trim();
                String availableLocation = availableLocationSpace.getText().toString().trim();

                if (bikeId.isEmpty() || bikeColour.isEmpty() || bikeNumber.isEmpty() ||
                        price.isEmpty() || availability.isEmpty() || availableLocation.isEmpty()) {
                    Toast.makeText(AddBikesActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else {
                    boolean isInserted = databaseHelper.addBike(bikeId, bikeColour, bikeNumber,
                            price, availability, availableLocation);
                    if (isInserted) {
                        Toast.makeText(AddBikesActivity.this, "Bike Added Successfully!", Toast.LENGTH_SHORT).show();
                        // Clear all fields
                        bikeIdSpace.setText("");
                        bikeColourSpace.setText("");
                        bikeNumberSpace.setText("");
                        priceSpace.setText("");
                        availabilitySpace.setText("");
                        availableLocationSpace.setText("");
                    } else {
                        Toast.makeText(AddBikesActivity.this, "Failed to Add Bike", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
