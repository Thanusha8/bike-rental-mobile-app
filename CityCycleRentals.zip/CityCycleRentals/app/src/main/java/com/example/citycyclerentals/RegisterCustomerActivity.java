package com.example.citycyclerentals;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterCustomerActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_customer);

        databaseHelper = new DatabaseHelper(this);

        EditText nameSpace = findViewById(R.id.customerregisternamespace);
        EditText emailSpace = findViewById(R.id.customeremailregisterspace);
        EditText passwordSpace = findViewById(R.id.customerregisterpasswordspace);
        Button registerButton = findViewById(R.id.customerregisterbutton);
        TextView loginLink = findViewById(R.id.loginlinkregister); // Login link

        // Navigate to login activity when clicked
        loginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterCustomerActivity.this, LoginCustomerActivity.class);
                startActivity(intent);
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameSpace.getText().toString().trim();
                String email = emailSpace.getText().toString().trim();
                String password = passwordSpace.getText().toString().trim();

                if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(RegisterCustomerActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else {
                    boolean isInserted = databaseHelper.registerUser(name, email, password);
                    if (isInserted) {
                        // Show success pop-up
                        Toast.makeText(RegisterCustomerActivity.this, "Customer Registered Successfully", Toast.LENGTH_SHORT).show();
                        // Clear fields
                        nameSpace.setText("");
                        emailSpace.setText("");
                        passwordSpace.setText("");
                    } else {
                        Toast.makeText(RegisterCustomerActivity.this, "Failed to Register Customer", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
