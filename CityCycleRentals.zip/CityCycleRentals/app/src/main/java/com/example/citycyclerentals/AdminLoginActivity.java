package com.example.citycyclerentals;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        EditText emailSpace = findViewById(R.id.emailspace);
        EditText passwordSpace = findViewById(R.id.passwordspace);
        Button loginButton = findViewById(R.id.adminloginbutton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailSpace.getText().toString();
                String password = passwordSpace.getText().toString();

                if (email.equals("admin@gmail.com") && password.equals("1234")) {
                    // Show a success message
                    Toast.makeText(AdminLoginActivity.this, "Successfully Login to the Admin Panel", Toast.LENGTH_SHORT).show();

                    // Navigate to Admin Dashboard
                    Intent intent = new Intent(AdminLoginActivity.this, AdminDashActivity.class);
                    startActivity(intent);
                } else {
                    // Show an error message
                    Toast.makeText(AdminLoginActivity.this, "Invalid Email or Password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
