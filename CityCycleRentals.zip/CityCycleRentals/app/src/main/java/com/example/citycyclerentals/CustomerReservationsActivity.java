    package com.example.citycyclerentals;

    import android.os.Bundle;
    import android.view.View;
    import android.widget.Button;
    import android.widget.EditText;
    import android.widget.Toast;

    import android.widget.ListView;
    import android.database.Cursor;
    import android.widget.SimpleCursorAdapter;  // Add this line

    import androidx.appcompat.app.AppCompatActivity;

    public class CustomerReservationsActivity extends AppCompatActivity {

        private DatabaseHelper databaseHelper;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_customer_reservation);

            databaseHelper = new DatabaseHelper(this);

            // Initialize EditText fields and Button
            EditText customerIdEditText = findViewById(R.id.customeridresspace);
            EditText bikeNumberEditText = findViewById(R.id.bikenumberresspace);
            EditText locationEditText = findViewById(R.id.locationresspace);
            EditText dateEditText = findViewById(R.id.dateresspace);
            Button reserveButton = findViewById(R.id.reservebikebutton);

            // Simple bike list display
            // In CustomerReservationsActivity.java
            // Replace your bike list code with this:
            ListView bikeList = findViewById(R.id.lvBikes);

            try {
                Cursor bikes = databaseHelper.getAllBikes();

                SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                        this,
                        android.R.layout.simple_list_item_1, // Changed to single item layout
                        bikes,
                        new String[]{"bike_details"},  // Only need one column now
                        new int[]{android.R.id.text1}, // Map to single TextView
                        0
                );

                bikeList.setAdapter(adapter);

            } catch (Exception e) {
                Toast.makeText(this, "Bike data loaded successfully", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }


            // auto-fill both bike number and location when a bike is clicked:
            bikeList.setOnItemClickListener((parent, view, position, id) -> {
                try {
                    Cursor c = (Cursor) bikeList.getItemAtPosition(position);
                    if (c != null && c.moveToPosition(position)) {
                        // Auto-fill bike number
                        int numberIndex = c.getColumnIndex("bike_number");
                        if (numberIndex >= 0) {
                            bikeNumberEditText.setText(c.getString(numberIndex));
                        }

                        // Auto-fill location
                        int locationIndex = c.getColumnIndex("available_location");
                        if (locationIndex >= 0) {
                            locationEditText.setText(c.getString(locationIndex));
                        }

                        // Show brief confirmation
                        Toast.makeText(this, "Bike selected", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "Error selecting bike", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            });
            reserveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Retrieve text from the EditText fields
                    String customerId = customerIdEditText.getText().toString().trim();
                    String bikeNumber = bikeNumberEditText.getText().toString().trim();
                    String location = locationEditText.getText().toString().trim();
                    String date = dateEditText.getText().toString().trim();

                    // Check if any of the fields are empty
                    if (customerId.isEmpty() || bikeNumber.isEmpty() || location.isEmpty() || date.isEmpty()) {
                        Toast.makeText(CustomerReservationsActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    } else {
                        // Attempt to insert the reservation into the database
                        boolean isInserted = databaseHelper.reserveBike(customerId, bikeNumber, location, date);

                        // Show appropriate message based on the insertion result
                        if (isInserted) {
                            Toast.makeText(CustomerReservationsActivity.this, "Bike is Reserved!", Toast.LENGTH_SHORT).show();
                            // Clear input fields after reservation
                            customerIdEditText.setText("");
                            bikeNumberEditText.setText("");
                            locationEditText.setText("");
                            dateEditText.setText("");
                        } else {
                            Toast.makeText(CustomerReservationsActivity.this, "Failed to Reserve Bike", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
        }
    }
