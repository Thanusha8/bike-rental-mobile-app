package com.example.citycyclerentals;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminDashActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dash);

        databaseHelper = new DatabaseHelper(this);  // Added this line

        Button addBikeButton = findViewById(R.id.addbikebutton);
        addBikeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AddBikesActivity
                Intent intent = new Intent(AdminDashActivity.this, AddBikesActivity.class);
                startActivity(intent);
            }
        });

        //  Delete All Customers Button
        Button deleteCustomersButton = findViewById(R.id.deleteCustomersButton);
        deleteCustomersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.deleteAllCustomers();
                Toast.makeText(AdminDashActivity.this, "All customers deleted", Toast.LENGTH_SHORT).show();
            }
        });

        // Delete All Bikes Button
        Button deleteBikesButton = findViewById(R.id.deleteBikesButton);
        deleteBikesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.deleteAllBikes();
                Toast.makeText(AdminDashActivity.this, "All bikes deleted", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
