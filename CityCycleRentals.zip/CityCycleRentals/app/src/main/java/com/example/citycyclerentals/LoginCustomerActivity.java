package com.example.citycyclerentals;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginCustomerActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_customer);

        databaseHelper = new DatabaseHelper(this);

        EditText emailSpace = findViewById(R.id.customerloginemailspace);
        EditText passwordSpace = findViewById(R.id.customerloginpasswordspace);
        Button loginButton = findViewById(R.id.customerloginbutton);
        TextView registerLink = findViewById(R.id.registerlinklogininterface); // Register link

        // Navigate to register activity when clicked
        registerLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginCustomerActivity.this, RegisterCustomerActivity.class); // Intent to navigate
                startActivity(intent);
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailSpace.getText().toString().trim();
                String password = passwordSpace.getText().toString().trim();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginCustomerActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else {
                    boolean isLoggedIn = databaseHelper.loginUser(email, password);
                    if (isLoggedIn) {
                        Toast.makeText(LoginCustomerActivity.this, "Successfully Logged In", Toast.LENGTH_SHORT).show();

                        // Start the CustomerReservationsActivity after successful login
                        Intent intent = new Intent(LoginCustomerActivity.this, CustomerReservationsActivity.class);
                        startActivity(intent);
                        finish();  // Close LoginActivity so the user can't go back to it
                    } else {
                        Toast.makeText(LoginCustomerActivity.this, "Invalid Email or Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
