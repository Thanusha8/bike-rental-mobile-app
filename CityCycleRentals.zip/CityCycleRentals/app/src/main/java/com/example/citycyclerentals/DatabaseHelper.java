package com.example.citycyclerentals;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CityCycleRentals.db";
    private static final int DATABASE_VERSION = 2;

    // Table and column names for Bikes
    private static final String TABLE_BIKES = "Bikes";
    private static final String COLUMN_BIKE_ID = "bike_id";
    private static final String COLUMN_BIKE_COLOUR = "bike_colour";
    private static final String COLUMN_BIKE_NUMBER = "bike_number";
    private static final String COLUMN_AVAILABLE_LOCATION = "available_location";

    private static final String COLUMN_PRICE = "price";   //add
    private static final String COLUMN_AVAILABILITY = "availability"; //add

    // Table and column names for Locations
    private static final String TABLE_LOCATIONS = "Locations";
    private static final String COLUMN_LOCATION_BIKE_NUMBER = "bike_number";
    private static final String COLUMN_LOCATION_NAME = "location";

    // Table and column names for Users
    private static final String TABLE_USERS = "Users";
    private static final String COLUMN_USER_NAME = "name";
    private static final String COLUMN_USER_EMAIL = "email";
    private static final String COLUMN_USER_PASSWORD = "password";



    // Table and column names for Reservations
    private static final String TABLE_RESERVATIONS = "Reservations";
    private static final String COLUMN_RESERVATION_ID = "reservation_id";
    private static final String COLUMN_CUSTOMER_ID = "customer_id";
    private static final String COLUMN_RESERVE_BIKE_NUMBER = "reserve_bike_number";
    private static final String COLUMN_LOCATION = "location";
    private static final String COLUMN_DATE = "date";

    // Create table SQL for Bikes
    private static final String CREATE_BIKES_TABLE =
            "CREATE TABLE " + TABLE_BIKES + " (" +
                    COLUMN_BIKE_ID + " TEXT PRIMARY KEY, " +
                    COLUMN_BIKE_COLOUR + " TEXT, " +
                    COLUMN_BIKE_NUMBER + " TEXT UNIQUE, " +
                    COLUMN_PRICE + " TEXT, " +
                    COLUMN_AVAILABILITY + " TEXT, " +
                    COLUMN_AVAILABLE_LOCATION + " TEXT)";      //add

    // Create table SQL for Locations
    private static final String CREATE_LOCATIONS_TABLE =
            "CREATE TABLE " + TABLE_LOCATIONS + " (" +
                    COLUMN_LOCATION_BIKE_NUMBER + " TEXT, " +
                    COLUMN_LOCATION_NAME + " TEXT, " +
                    "FOREIGN KEY(" + COLUMN_LOCATION_BIKE_NUMBER + ") REFERENCES " + TABLE_BIKES + "(" + COLUMN_BIKE_NUMBER + "))";

    // Create table SQL for Users
    private static final String CREATE_USERS_TABLE =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_USER_EMAIL + " TEXT PRIMARY KEY, " +
                    COLUMN_USER_NAME + " TEXT, " +
                    COLUMN_USER_PASSWORD + " TEXT)";

    // Create table SQL for Reservations
    private static final String CREATE_RESERVATIONS_TABLE =
            "CREATE TABLE " + TABLE_RESERVATIONS + " (" +
                    COLUMN_RESERVATION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_CUSTOMER_ID + " TEXT, " +
                    COLUMN_RESERVE_BIKE_NUMBER + " TEXT, " +
                    COLUMN_LOCATION + " TEXT, " +
                    COLUMN_DATE + " TEXT, " +
                    "FOREIGN KEY(" + COLUMN_RESERVE_BIKE_NUMBER + ") REFERENCES " + TABLE_BIKES + "(" + COLUMN_BIKE_NUMBER + "))";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_BIKES_TABLE);
        db.execSQL(CREATE_LOCATIONS_TABLE);
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_RESERVATIONS_TABLE); // Create the Reservations table
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BIKES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOCATIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESERVATIONS); // Drop Reservations table if it exists
        onCreate(db);
    }

    // Add a bike to the Bikes table
    public boolean addBike(String bikeId, String bikeColour, String bikeNumber,String price, String availability, String availableLocation) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_BIKE_ID, bikeId);
        values.put(COLUMN_BIKE_COLOUR, bikeColour);
        values.put(COLUMN_BIKE_NUMBER, bikeNumber);
        values.put(COLUMN_PRICE, price);
        values.put(COLUMN_AVAILABILITY, availability);    //add
        values.put(COLUMN_AVAILABLE_LOCATION, availableLocation);

        long result = db.insert(TABLE_BIKES, null, values);
        return result != -1; // If insertion is successful, result will not be -1
    }

    // Add a location to the Locations table
    public boolean addLocation(String bikeNumber, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_LOCATION_BIKE_NUMBER, bikeNumber);
        values.put(COLUMN_LOCATION_NAME, location);

        long result = db.insert(TABLE_LOCATIONS, null, values);
        return result != -1; // If insertion is successful, result will not be -1
    }

    // Register a new user in the Users table
    public boolean registerUser(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_USER_NAME, name);
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_USER_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1; // If insertion is successful, result will not be -1
    }

    // Authenticate user login from the Users table
    public boolean loginUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " +
                COLUMN_USER_EMAIL + " = ? AND " + COLUMN_USER_PASSWORD + " = ?", new String[]{email, password});

        boolean isLoggedIn = cursor.getCount() > 0;
        cursor.close();
        return isLoggedIn;
    }

    // Method to insert a reservation into the Reservations table
    public boolean reserveBike(String customerId, String bikeNumber, String location, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_CUSTOMER_ID, customerId);
        values.put(COLUMN_RESERVE_BIKE_NUMBER, bikeNumber);
        values.put(COLUMN_LOCATION, location);
        values.put(COLUMN_DATE, date);

        long result = db.insert(TABLE_RESERVATIONS, null, values);
        return result != -1; // If insertion is successful, result will not be -1
    }

    public Cursor getAllBikes() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT bike_id AS _id, bike_number, available_location, " +
                "'Bike Number:        ' || bike_number || '\n' || " +
                "'Type and Colour:  ' || bike_colour || '\n' || " +
                "'Price/Day:              ₨ ' || price || '\n' || " +
                "'Availability:            ' || availability || '\n' || " +
                "'Location:                ' || available_location AS bike_details " +
                "FROM " + TABLE_BIKES, null);
    }

    // Add these new methods
    public void deleteAllCustomers() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_USERS);
        db.execSQL("DELETE FROM " + TABLE_RESERVATIONS); // Also clear reservations
    }

    public void deleteAllBikes() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_BIKES);
        db.execSQL("DELETE FROM " + TABLE_RESERVATIONS); // Also clear reservations
        db.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME='" + TABLE_RESERVATIONS + "'");
    }
}
